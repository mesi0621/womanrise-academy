import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ElearnTest {

    User user;
    Teacher teacher;
    Student student;
    Course course;
    Quiz quiz;
    Lesson lesson;

    @BeforeEach
    void setUp() {
        user = new User("user@example.com", "Mesi", "1234", 1);
        teacher = new Teacher("teacher@example.com", "Mr. John", "abcd", 2, 101);
        student = new Student("student@example.com", "Sara", "pass", 3, 201);
        course = new Course("Math 101");
        quiz = new Quiz("Java Basics");
        lesson = new Lesson("Introduction to Java");
    }

    // User tests
    @Test
    void testUserLogin() {
        assertTrue(user.login("user@example.com", "1234"));
        assertFalse(user.login("user@example.com", "wrong"));
    }

    @Test
    void testUserLogout() {
        user.logout(); // prints only
    }

    // Teacher tests
    @Test
    void testTeacherActions() {
        assertTrue(teacher.login("teacher@example.com", "abcd"));
        teacher.createCourse(course.getCourseName());
        teacher.createQuiz(quiz.getQuizName());
        teacher.generateReports();
    }

    // Student tests
    @Test
    void testStudentEnroll() {
        assertTrue(student.login("student@example.com", "pass"));
        student.enrollCourse(course.getCourseName());
    }

    // Course, Quiz, Lesson getters/setters
    @Test
    void testCourseQuizLesson() {
        assertEquals("Math 101", course.getCourseName());
        course.setCourseName("Physics 101");
        assertEquals("Physics 101", course.getCourseName());

        assertEquals("Java Basics", quiz.getQuizName());
        quiz.setQuizName("Python Basics");
        assertEquals("Python Basics", quiz.getQuizName());

        assertEquals("Introduction to Java", lesson.getLessonName());
        lesson.setLessonName("Intro to Python");
        assertEquals("Intro to Python", lesson.getLessonName());
    }
}
