public class Student extends User {
    private int studentId;

    public Student() {}
    public Student(String email, String name, String password, int userId, int studentId) {
        super(email, name, password, userId);
        this.studentId = studentId;
    }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public void enrollCourse(String courseName) {
        System.out.println(getName() + " enrolled in " + courseName);
    }
}
