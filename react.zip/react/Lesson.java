public class Lesson {
    private String lessonName;

    public Lesson(String lessonName) { this.lessonName = lessonName; }

    public String getLessonName() { return lessonName; }
    public void setLessonName(String lessonName) { this.lessonName = lessonName; }
}
